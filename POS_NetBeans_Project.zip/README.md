Simple POS Java Swing project
Instructions to import into NetBeans:
1. In NetBeans, choose File > New Project > Java with Ant > Java Application.
2. Replace the auto-generated src folder contents with the files from this project, or create a new project and copy the .java files into the project's "Source Packages" (no package).
3. Set Main.java as the main class and run the project.
This project stores sales history to a file in the user's home directory named "pos_sales_history.csv".
